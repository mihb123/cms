@extends('jigyosho::layout')

@section('title', 'Trang chủ - Life Star')

@section('content')

    <div class="top-img-container">
        <div class="top-img"></div>
    </div>
    <!-- section01 start-->
    <div class="section-1">
        <div class="container">
            <div class="search-option-text">Search by area</div>
            <div style="display: flex">
                <div class="search-option-logo__text top-text">［Tokyo-東京］</div>
                <div class="dropdown-option-text">
                    <div class="dropdown-option-text-1">東京都の療養支援事業者数</div>
                    <div class="dropdown-option-text-2">
                        <div>4,830</div>
                        <div>件</div>
                    </div>
                </div>
            </div>
            <div class="search-option">
                <div class="address-title-option">
                    <div class="search-option-title option-address__toggle-dropdown active">
                        <div class="search-option-title__text-box item--show1 ">
                            <span class="search-option-title__text--big">エリアから探す</span>
                            <span class="search-option-title__text--middle">（東京都）</span>
                        </div>
                        <svg class="triangle-indicator" width="41" height="20" viewBox="0 0 41 20">
                            <path d="M0,0H41L20.5,19Z" fill="#ffb1bf" />
                        </svg>
                    </div>
                    <div class="search-option-title option-address__toggle-map">
                        <div class="search-option-title__text-box item--show1">
                            <span class="search-option-title__text--big">地図から探す</span><span
                                class="search-option-title__text--middle">（東京都）</span>
                        </div>
                        <svg class="triangle-indicator" width="41" height="20" viewBox="0 0 41 20">
                            <path d="M0,0H41L20.5,19Z" fill="#ffb1bf" />
                        </svg>
                    </div>
                </div>
                <div class="search-option-logo">
                    <div class="search-option-logo__img-box">
                        <!-- <img class="search-option-logo__img-box--pc" src="{{ asset('frontend/jigyosho/issets/images/select01/Group 298.svg') }}" alt="" /> -->
                        <img class="search-option-logo__img-box--pc"
                            src="{{ asset('frontend/jigyosho/issets/images/select01/Group 300.svg') }}" alt="" />
                    </div>
                </div>
            </div>
        </div>
        <!-- title add end -->

        <div class="option-address-container">
            <p class="text-address">
                ご自宅のあるエリアから自宅療養を支えてくれる人たちを探す
            </p>
            <div class="option-address">
                <!-- list checkbox banner one start-->
                <div class="option-address__toggle">
                    <div class="option-address__item item--show1">
                        <div class="option-address__img">
                            <img src="{{ asset('frontend/jigyosho/issets/images/select01/img1.svg') }}" alt="" />
                        </div>
                        <div class="option-address__text">
                            <span class="option-address__text--middle">区</span>
                            <span class="option-address__text--small">（23区）</span>
                        </div>
                    </div>

                    <div class="option-address__arrow-icon item--show1" id="arrow-one">
                        <img src="{{ asset('frontend/jigyosho/issets/images/arrow-right.svg') }}" alt="" />
                    </div>

                    <div class="option-address__check-box option-address__check-box--position1">
                        <div class="option-address__checkboxs">
                            @foreach(array_chunk($districts, 8) as $column)
                                <div class="option-address__col option-address__col-one">
                                    @foreach($column as $index => $district)
                                        @php
                                            $checkboxId = "option1-checkbox" . ($loop->parent->index * 8 + $index + 1);
                                        @endphp
                                        <p class="option-address__checkboxs-item">
                                            <input class="banner-checkboxs__item-ip" type="checkbox" name="cb_addr21"
                                                id="{{ $checkboxId }}" />
                                            <label class="banner-label" for="{{ $checkboxId }}">
                                                <span class="banner-label--middle">{{ $district }}</span>
                                            </label>
                                        </p>
                                    @endforeach
                                </div>
                            @endforeach
                        </div>

                        <div class="select-btn2">
                            <div class="select-btn2__arrow-icon">
                                <img src="{{ asset('frontend/jigyosho/issets/images/arrow-right.svg') }}" alt="" />
                            </div>
                            <div class="select-btn2__item--pink select-round disabled" id="select-round-one"
                                position="position1">
                                <p class="select-btn2__text--white">決定</p>
                            </div>
                            <div class="select-btn2__item--white select-btn__item--outline" id="clear-checkbox-op1">
                                <p class="select-btn2__text--pink">リセット</p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- list checkbox banner one end-->

                <!-- list checkbox banner two start-->
                <div class="option-address__toggle">
                    <div class="option-address__item item--show2">
                        <div class="option-address__img">
                            <img src="{{ asset('frontend/jigyosho/issets/images/select01/img2.svg') }}" alt="" />
                        </div>
                        <div class="option-address__text">
                            <span class="option-address__text--middle">市</span>
                            <span class="option-address__text--small">（26市）</span>
                        </div>
                    </div>

                    <div class="option-address__arrow-icon item--show2" id="arrow-two">
                        <img src="{{ asset('frontend/jigyosho/issets/images/arrow-right.svg') }}" alt="" />
                    </div>

                    <div class="option-address__check-box option-address__check-box--position2">
                        <div class="option-address__checkboxs">
                            @foreach(array_chunk($cities, 9) as $column)
                                <div class="option-address__col option-address__col-one">
                                    @foreach($column as $index => $cities)
                                        @php
                                            $checkboxId = "option2-checkbox" . ($loop->parent->index * 9 + $index + 1);
                                        @endphp
                                        <p class="option-address__checkboxs-item">
                                            <input class="banner-checkboxs__item-ip" type="checkbox" name="cb_addr21"
                                                id="{{ $checkboxId }}" />
                                            <label class="banner-label" for="{{ $checkboxId }}">
                                                <span class="banner-label--middle"> {{ $cities }}</span>
                                            </label>
                                        </p>
                                    @endforeach
                                </div>
                            @endforeach
                        </div>

                        <div class="select-btn2">
                            <div class="select-btn2__arrow-icon">
                                <img src="{{ asset('frontend/jigyosho/issets/images/arrow-right.svg') }}" alt="" />
                            </div>
                            <div class="select-btn2__item--pink select-round disabled" id="select-round-one"
                                position="position1">
                                <p class="select-btn2__text--white">決定</p>
                            </div>
                            <div class="select-btn2__item--white select-btn__item--outline" id="clear-checkbox-op1">
                                <p class="select-btn2__text--pink">リセット</p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- list checkbox banner two end-->

                <!-- list checkbox banner three start-->
                <div class="option-address__toggle">
                    <div class="option-address__item item--show3">
                        <div class="option-address__img">
                            <img src="{{ asset('frontend/jigyosho/issets/images/select01/img3.svg') }}" alt="" />
                        </div>
                        <div class="option-address__text">
                            <span class="option-address__text--middle">町</span>
                            <span class="option-address__text--small">（5町）</span>
                        </div>
                    </div>

                    <div class="option-address__arrow-icon item--show3" id="arrow-three">
                        <img src="{{ asset('frontend/jigyosho/issets/images/arrow-right.svg') }}" alt="" />
                    </div>

                    <div class="option-address__check-box option-address__check-box--position3">
                        <div class="option-address__checkboxs">
                            @foreach(array_chunk($towns, 2) as $column)
                                <div class="option-address__col option-address__col-seven">
                                    @foreach($column as $index => $town)
                                        @php
                                            $checkboxId = "option7-checkbox" . ($loop->parent->index * 2 + $index + 1);
                                        @endphp
                                        <p class="option-address__checkboxs-item">
                                            <input class="banner-checkboxs__item-ip" type="checkbox" name="cb_addr21"
                                                id="{{ $checkboxId }}" />
                                            <label class="banner-label" for="{{ $checkboxId }}">
                                                <span class="banner-label--middle">{{ $town }}</span>
                                            </label>
                                        </p>
                                    @endforeach
                                </div>
                            @endforeach
                        </div>

                        <div class="select-btn2">
                            <div class="select-btn2__arrow-icon">
                                <img src="{{ asset('frontend/jigyosho/issets/images/arrow-right.svg') }}" alt="" />
                            </div>

                            <div class="select-btn2__item--pink select-round disabled" id="select-round-three"
                                position="position3">
                                <p class="select-btn2__text--white">決定</p>
                            </div>
                            <div class="select-btn2__item--white select-btn__item--outline" id="clear-checkbox-op3">
                                <p class="select-btn2__text--pink">リセット</p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- list checkbox banner three end-->


                <!-- list checkbox banner four start-->
                <div class="option-address__toggle">
                    <div class="option-address__item item--show4">
                        <div class="option-address__img">
                            <img src="{{ asset('frontend/jigyosho/issets/images/select01/img4.svg') }}" alt="" />
                        </div>
                        <div class="option-address__text">
                            <span class="option-address__text--middle">村</span>
                            <span class="option-address__text--small">（8村）</span>
                        </div>
                    </div>

                    <div class="option-address__arrow-icon item--show4" id="arrow-four">
                        <img src="{{ asset('frontend/jigyosho/issets/images/arrow-right.svg') }}" alt="" />
                    </div>

                    <div class="option-address__check-box option-address__check-box--position4">
                        <div class="option-address__checkboxs">
                            @foreach(array_chunk($villages, 3) as $column)
                                <div class="option-address__col option-address__col-ten">
                                    @foreach($column as $index => $village)
                                        @php
                                            $checkboxId = "option10-checkbox" . ($loop->parent->index * 3 + $index + 1);
                                        @endphp
                                        <p class="option-address__checkboxs-item">
                                            <input class="banner-checkboxs__item-ip" type="checkbox" name="cb_addr21"
                                                id="{{ $checkboxId }}" />
                                            <label class="banner-label" for="{{ $checkboxId }}">
                                                <span class="banner-label--middle">{{ $village }}</span>
                                            </label>
                                        </p>
                                    @endforeach
                                </div>
                            @endforeach
                        </div>

                        <div class="select-btn2">
                            <div class="select-btn2__arrow-icon">
                                <img src="{{ asset('frontend/jigyosho/issets/images/arrow-right.svg') }}" alt="" />
                            </div>

                            <div class="select-btn2__item--pink select-round disabled" id="select-round-four"
                                position="position4">
                                <p class="select-btn2__text--white">決定</p>
                            </div>
                            <div class="select-btn2__item--white select-btn__item--outline" id="clear-checkbox-op4">
                                <p class="select-btn2__text--pink">リセット</p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- list checkbox banner four end-->
            </div>
            @include('jigyosho::partials.clckbl_map')
        </div>

        <div class="search-option">
            <div class="search-option-title option-category__toggle">
                <div class="search-option-title__text-box item--show1 ">
                    <span class="search-option-title__text--big">サポートの分類から探す</span>
                </div>
                <svg class="triangle-indicator" width="41" height="20" viewBox="0 0 41 20">
                    <path d="M0,0H41L20.5,19Z" fill="#ffb1bf" />
                </svg>
            </div>
            <div class="search-option-logo">
                <div class="search-option-logo__img-box">
                    <!-- <img class="search-option-logo__img-box--pc" src="{{ asset('frontend/jigyosho/issets/images/select01/Group 298.svg') }}" alt="" /> -->
                    <img class="search-option-logo__img-box--pc"
                        src="{{ asset('frontend/jigyosho/issets/images/select01/Group 300.svg') }}" alt="" />
                </div>
            </div>
        </div>
    </div>



    <div class="option-category-container"></div>
    </div>
    </div>
    <!-- section01 end-->
    </div>
@endsection
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const titles = document.querySelectorAll(".search-option-title");

        const optionAddressItem = document.querySelectorAll(".option-address__item");
        const optionAddressSelection = document.querySelector(".option-address");
        const optionAddressMap = document.querySelector("#clickable-map");

        let text = document.querySelector(".dropdown-option-text");
        titles.forEach(title => {
            title.addEventListener("click", function () {
                if ((this.classList.contains("option-address__toggle-dropdown")) ||
                    (this.classList.contains("option-address__toggle-map"))) {
                    titles.forEach(title => { title.classList.remove('active') })
                    this.classList.add("active");
                    // Address - Display Dropdown list
                    if ((this.classList.contains("option-address__toggle-dropdown") && this.classList.contains("active"))) {
                        optionAddressSelection.style.display = "grid";
                        text.style.display = "grid";
                    } else {
                        optionAddressSelection.style.display = "none";
                        text.style.display = "none";
                    }
                    // Address - Display Clickable map
                    if ((this.classList.contains("option-address__toggle-map") && this.classList.contains("active"))) {
                        optionAddressMap.style.display = "grid";
                    } else {
                        optionAddressMap.style.display = "none";
                    }

                } else {
                    // Category
                    titles.forEach(temp => { temp.classList.remove("active") });
                    this.classList.add("active");
                }
            });
        });
    });
</script>