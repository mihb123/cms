<!-- section5 start -->
<div class="section-5">
    <a href="/inquiry.php">
        <div class="section-5-qa">
            <div class="section-5-qa__text-wrap">
                <p class="section-5-qa__text">お問い合わせフォームからのご相談は</p>
                <p class="section-5-qa__text">こちらからお気軽にどうぞ</p>
            </div>

            <div class="section-5-qa__email">
                <img class="section-5-qa__img" src="./issets/images/mail.svg" alt="" />
            </div>
        </div>
    </a>
</div>
<!-- section5 end -->